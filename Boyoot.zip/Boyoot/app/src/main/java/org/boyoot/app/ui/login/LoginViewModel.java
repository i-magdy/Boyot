package org.boyoot.app.ui.login;

import androidx.lifecycle.ViewModel;

public class LoginViewModel extends ViewModel {
}
